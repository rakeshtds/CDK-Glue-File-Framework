// ============================================================
// FCUDLGlueTableFramework.ts
// Orchestrator CDK Construct.
// Reads all schema files → creates one FCUDLGlueTableConstruct
// + one FCUDLGluePartitionRefresher per table.
// This is what FCUDLGlueTableStack instantiates internally.
// ============================================================

import { Construct } from "constructs";
import * as s3 from "aws-cdk-lib/aws-s3";
import { FCUDLGlueSchemaLoader } from "./FCUDLGlueSchemaLoader";
import { FCUDLGlueTableConstruct } from "./FCUDLGlueTableConstruct";
import { FCUDLGluePartitionRefresher } from "./FCUDLGluePartitionRefresher";
import { ResolvedTableConfig } from "./FCUDLGlueTypes";

export interface FCUDLGlueTableFrameworkProps {
  /** Directory containing .json / .yaml schema files */
  schemaDirectory?: string;
  /** Pass schemas programmatically instead of loading from files */
  schemas?:         ResolvedTableConfig[];
  /** Shared S3 bucket for all tables */
  sharedBucket?:    s3.IBucket;
}

export class FCUDLGlueTableFramework extends Construct {

  /** tableName → construct, for downstream access in infra.ts */
  public readonly tables:    Map<string, FCUDLGlueTableConstruct>      = new Map();
  public readonly refreshers: Map<string, FCUDLGluePartitionRefresher> = new Map();
  public readonly resolvedSchemas: ResolvedTableConfig[];

  constructor(scope: Construct, id: string, props: FCUDLGlueTableFrameworkProps) {
    super(scope, id);

    // ── LOAD SCHEMAS ─────────────────────────────────────────
    this.resolvedSchemas = props.schemas
      ?? FCUDLGlueSchemaLoader.loadFromDirectory(props.schemaDirectory!);

    if (this.resolvedSchemas.length === 0) {
      throw new Error("FCUDLGlueTableFramework: No schemas loaded.");
    }

    console.log(
      `[FCUDLGlueTableFramework] Deploying ${this.resolvedSchemas.length} table(s): ` +
      this.resolvedSchemas.map((s) => `${s.database}.${s.tableName}`).join(", ")
    );

    // ── CREATE ONE CONSTRUCT SET PER SCHEMA ──────────────────
    for (const schema of this.resolvedSchemas) {
      const safeId = `${schema.database}-${schema.tableName}`;

      const tableConstruct = new FCUDLGlueTableConstruct(this, `Table-${safeId}`, {
        schema,
        sharedBucket: props.sharedBucket,
      });
      this.tables.set(schema.tableName, tableConstruct);

      const refresher = new FCUDLGluePartitionRefresher(this, `Refresher-${safeId}`, {
        schema,
        bucket: tableConstruct.bucket,
      });
      this.refreshers.set(schema.tableName, refresher);
    }
  }
}
