// ============================================================
// PSUDLGlueTableStack.ts
// The CDK Stack class imported and instantiated by infra.ts.
// No cdk.App here — app is owned by infra/bin/app.ts.
//
// Usage in infra.ts:
//   import { PSUDLGlueTableStack } from "../lib/GLUE/PSUDLGlueTableStack";
//
//   new PSUDLGlueTableStack(app, "PSUDLGlueStack-dev", {
//     env:             { account: config.account, region: config.region },
//     environment:     config.environment,
//     schemaDirectory: path.join(__dirname, "../schemas"),
//     bucketName:      config.dataLakeBucketName,
//   });
// ============================================================

import * as cdk  from "aws-cdk-lib";
import * as s3   from "aws-cdk-lib/aws-s3";
import * as path from "path";
import { Construct } from "constructs";

import { PSUDLGlueTableFramework }    from "./PSUDLGlueTableFramework";
import { PSUDLGlueTableConstruct }    from "./PSUDLGlueTableConstruct";
import { PSUDLGluePartitionRefresher } from "./PSUDLGluePartitionRefresher";
import { ResolvedTableConfig }         from "./PSUDLGlueTypes";

// ── PROPS ─────────────────────────────────────────────────────
export interface PSUDLGlueTableStackProps extends cdk.StackProps {
  /**
   * Path to the folder containing your .json / .yaml schema files.
   * Defaults to infra/schemas/ if not provided.
   */
  schemaDirectory?: string;

  /**
   * Name of the shared S3 data lake bucket.
   * Auto-named data-lake-{account}-{region} if not provided.
   */
  bucketName?: string;

  /**
   * Pass an already-existing bucket instead of creating a new one.
   * Takes precedence over bucketName.
   */
  existingBucket?: s3.IBucket;

  /**
   * Supply schemas programmatically instead of loading from files.
   * Useful when infra.ts builds schema objects dynamically.
   */
  schemas?: ResolvedTableConfig[];

  /**
   * Environment name — dev | staging | prod
   * Applied as a tag to every resource in the stack.
   */
  environment: string;
}

// ── STACK ─────────────────────────────────────────────────────
export class PSUDLGlueTableStack extends cdk.Stack {

  /** The shared S3 data lake bucket */
  public readonly dataLakeBucket: s3.IBucket;

  /** The framework construct — loop tables / refreshers from here */
  public readonly glueFramework: PSUDLGlueTableFramework;

  /** tableName → PSUDLGlueTableConstruct */
  public readonly tables: Map<string, PSUDLGlueTableConstruct>;

  /** tableName → PSUDLGluePartitionRefresher */
  public readonly refreshers: Map<string, PSUDLGluePartitionRefresher>;

  /** All resolved schemas loaded at synth time */
  public readonly resolvedSchemas: ResolvedTableConfig[];

  constructor(scope: Construct, id: string, props: PSUDLGlueTableStackProps) {
    super(scope, id, props);

    const { environment, schemaDirectory, bucketName, existingBucket, schemas } = props;

    // ── STACK-WIDE TAGS ───────────────────────────────────────
    cdk.Tags.of(this).add("ManagedBy",   "PSUDLGlueTableStack");
    cdk.Tags.of(this).add("Environment", environment);
    cdk.Tags.of(this).add("Domain",      "finance");
    cdk.Tags.of(this).add("CostCenter",  "data-platform");

    // ── S3 DATA LAKE BUCKET ───────────────────────────────────
    // Priority: existingBucket → bucketName → auto-name
    if (existingBucket) {
      this.dataLakeBucket = existingBucket;

    } else {
      const resolvedName = bucketName
        ?? `data-lake-${this.account}-${this.region}`;

      this.dataLakeBucket = new s3.Bucket(this, "DataLakeBucket", {
        bucketName:        resolvedName,
        encryption:        s3.BucketEncryption.S3_MANAGED,
        blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
        versioned:         false,
        lifecycleRules: [
          {
            transitions: [
              {
                storageClass:    s3.StorageClass.INFREQUENT_ACCESS,
                transitionAfter: cdk.Duration.days(90),
              },
              {
                storageClass:    s3.StorageClass.GLACIER,
                transitionAfter: cdk.Duration.days(365),
              },
            ],
          },
        ],
        removalPolicy: cdk.RemovalPolicy.RETAIN,
      });
    }

    // ── GLUE TABLE FRAMEWORK ──────────────────────────────────
    // Defaults to ../../schemas relative to compiled JS location
    // i.e. infra/schemas/ from infra/lib/GLUE/
    const resolvedSchemaDir = schemaDirectory
      ?? path.join(__dirname, "../../schemas");

    this.glueFramework = new PSUDLGlueTableFramework(this, "PSUDLGlueTableFramework", {
      schemaDirectory: schemas ? undefined : resolvedSchemaDir,
      schemas,
      sharedBucket:    this.dataLakeBucket,
    });

    // ── SHORTCUTS ─────────────────────────────────────────────
    this.tables          = this.glueFramework.tables;
    this.refreshers      = this.glueFramework.refreshers;
    this.resolvedSchemas = this.glueFramework.resolvedSchemas;

    // ── CLOUDFORMATION OUTPUTS ────────────────────────────────
    new cdk.CfnOutput(this, "DataLakeBucketName", {
      value:       this.dataLakeBucket.bucketName,
      description: "Shared S3 data lake bucket",
      exportName:  `${id}-DataLakeBucket`,
    });

    new cdk.CfnOutput(this, "GlueDatabase", {
      value:       this.resolvedSchemas[0]?.database ?? "finance_raw",
      description: "Glue database name — use this in Athena",
      exportName:  `${id}-GlueDatabase`,
    });

    new cdk.CfnOutput(this, "TablesDeployed", {
      value:       Array.from(this.tables.keys()).join(", "),
      description: "All Glue tables deployed",
    });
  }
}
